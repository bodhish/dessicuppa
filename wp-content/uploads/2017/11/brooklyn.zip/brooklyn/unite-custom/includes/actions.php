<?php if (!defined('ABSPATH')) {
    exit; // exit if accessed directly
}